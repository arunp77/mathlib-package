def power(base, exp):
    return base ** exp

def sqrt(x):
    return x ** 0.5

def cbrt(x):
    return x ** (1/3)
